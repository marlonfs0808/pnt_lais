import React from 'react';
import { View, Text, Image, Button, StyleSheet } from 'react-native';

const MyComponent = () => {
  return (
    <View style={styles.container}>
      <Image
        source={{ uri: 'URL_DA_IMAGEM' }}
        style={styles.image}
      />
      <Text style={styles.text}>Seu texto aqui.</Text>
      <Button
        title="Clique-me"
        onPress={() => {
          // Lógica a ser executada quando o botão for pressionado
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: 200,
    height: 200,
    resizeMode: 'cover',
    marginBottom: 20,
  },
  text: {
    fontSize: 20,
    marginBottom: 20,
  },
});


