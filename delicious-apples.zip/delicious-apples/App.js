import React from 'react';
import { View, Text, Image, Button, StyleSheet } from 'react-native';

const MyComponent = () => {
  return (
    <View style={styles.container}>
      <Image
        source={{ uri: 'https://www.vagalume.com.br/lana-del-rey/discografia/born-to-die.jpg' }} // 
        style={styles.image}
      />
      <Text style={styles.text}>Lana Del Rey não apenas é uma mulher bonita e sensual, como também não tem pudores em usar essa beleza e sensualidade em sua música. Não é a primeira e nem será a última cantora (ou cantor) a fazer isso.</Text>
      <Button
        title="SAIBA MAIS"
        onPress={() => {
         
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#96bffd', 
  },
  image: {
    width: 200,
    height: 200,
    resizeMode: 'cover',
    marginBottom: 20,
  },
  text: {
    fontSize: 20,
    marginBottom: 20,
    color: 'black', // Cor do texto
  },
});

const App = () => {
  return (
    <View style={styles.container}>
      <MyComponent />
    </View>
  );
};

conststyles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff', // Cor de fundo do App
  },
});

export default App;